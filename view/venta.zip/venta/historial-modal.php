<div id="historialModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body" id="modal-historial">
			    <?php include("ventaproducto.php"); ?>
          	</div>
      	</div>
	</div>
</div>