<div id="detallesModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body" id="modal-detalles">
          	</div>
      	</div>
	</div>
</div>