<h1 class="page-header">Historial de venta del producto</h1>

<br><br><br>
<table class="table table-striped table-bordered display responsive nowrap ">

    <thead>
        <tr style="background-color: black; color:#fff">
            <th>Vendedor</th>
            <th>Producto</th>    
            <th>Cliente</th>
            <th>Precio</th>
            <th>Fecha</th>
    </thead>
    <tbody>
    <?php 
    $suma = 0; $count = 0;  
    foreach($this->venta->ListarProducto($_GET['id_producto']) as $r): ?>
        <tr class="click" <?php if($r->anulado){echo "style='color:gray'";} ?>>
            <td><?php echo $r->vendedor; ?></td>
            <td><?php echo $r->producto; ?></td>    
            <td><?php echo $r->nombre_cli; ?></td>
            <td><?php echo number_format($r->precio_venta,0,".",","); ?></td>
            <td><?php echo date("d/m/Y", strtotime($r->fecha_venta)); ?></td>
        </tr>
    <?php 
        $count++;
    endforeach; ?>
    </tbody>
    
</table>
</div>
</div>
<?php include("view/crud-modal.php"); ?>
<?php include("view/venta/detalles-modal.php"); ?>

