<?php
require_once 'model/venta.php';
require_once 'model/usuario.php';
require_once 'model/compra.php';
require_once 'model/venta_tmp.php';
require_once 'model/producto.php';
require_once 'model/ingreso.php';
require_once 'model/deuda.php';
require_once 'model/egreso.php';
require_once 'model/cierre.php';
require_once 'model/caja.php';
require_once 'model/cliente.php';


class ventaController{
    
    private $model;
    
    public function __CONSTRUCT(){
        $this->model = new venta();
        $this->venta = new venta();
        $this->usuario = new usuario();
        $this->compra = new compra();
        $this->venta_tmp = new venta_tmp();
        $this->producto = new producto();
        $this->ingreso = new ingreso();
        $this->deuda = new deuda();
        $this->egreso = new egreso();
        $this->cierre = new cierre();
        $this->caja = new caja();
        $this->cliente = new cliente();
    }
    
    public function Index(){
        require_once 'view/header.php';
        require_once 'view/venta/venta.php';
        require_once 'view/footer.php';
       
    }

    public function Sesion(){
        require_once 'view/header.php';
        if ($cierre = $this->cierre->Consultar($_SESSION['user_id'])) {          
            require_once 'view/venta/venta-sesion.php';
        }else{
            echo "<h1>Debe hacer apertura de caja</h1>";
        }
        require_once 'view/footer.php';
    }

    public function NuevaVenta(){
        require_once 'view/header.php';
        require_once 'view/venta/nueva-venta.php';
        require_once 'view/footer.php';
       
    }


    public function Listar(){
        require_once 'view/venta/venta.php';
    }
    
    public function ListarCliente(){
        require_once 'view/header.php';
        require_once 'view/venta/ventacliente.php';
        require_once 'view/footer.php';
    }
    
    public function ListarUsuario(){
        require_once 'view/header.php';
        require_once 'view/venta/ventausuario.php';
        require_once 'view/footer.php';
    }
    
    public function ListarProducto(){
        require_once 'view/header.php';
        require_once 'view/venta/ventaproducto.php';
        require_once 'view/footer.php';
    }
    

    public function detalles(){
        require_once 'view/venta/venta_detalles.php';
    }
    
    
    public function ListarDia(){
        
        require_once 'view/header.php';
        require_once 'view/venta/ventadia.php';
        require_once 'view/footer.php';
    }

    public function Cambiar(){

        $venta = new venta();
        
        $id_item = $_REQUEST['id_item'];
        $id_venta = $_REQUEST['id_venta'];
        $cantidad = $_REQUEST['cantidad'];
        $codigo = $_REQUEST['codigo'];
        $cantidad_ant = $_REQUEST['cantidad_ant'];
        
        $cant = $cantidad_ant - $cantidad;

        if($cantidad>0){
            $venta = $this->model->Cantidad($id_item, $id_venta, $cantidad);
            
            if($venta->contado=='Cuota')
                $deuda = $this->deuda->EditarMonto($id_venta, $venta->total_venta);

            if($venta->contado=='Contado')
                $deuda = $this->ingreso->EditarMonto($id_venta, $venta->total_venta);

            
            $this->producto->Sumar($codigo, $cant);

        }
        
        echo json_encode($venta);
    }

    public function Cancelar(){
        
        $id_item = $_REQUEST['id_item'];
        $id_venta = $_REQUEST['id_venta'];
        $codigo = $_REQUEST['codigo'];
        $cantidad = $_REQUEST['cantidad_item'];


        $venta = $this->model->Cantidad($id_item, $id_venta, 0);
            
        if($venta->contado=='Cuota')
            $deuda = $this->deuda->EditarMonto($id_venta, $venta->total_venta);

        if($venta->contado=='Contado')
            $deuda = $this->ingreso->EditarMonto($id_venta, $venta->total_venta);

        $venta = $this->model->CancelarItem($id_item);
        $this->producto->Sumar($codigo, $cantidad);
        header('location: ?c=venta_tmp&a=editar&id='.$id_venta);
    }


    
    public function Crud(){
        $venta = new venta();
        
        if(isset($_REQUEST['id'])){
            $venta = $this->model->Obtener($_REQUEST['id']);
        }
        
        require_once 'view/header.php';
        require_once 'view/venta/venta-editar.php';
        require_once 'view/footer.php';
    }

    public function Cierre(){
        
        require_once 'view/informes/cierrepdf.php';
        
    }
    
    public function CierreMes(){
        $venta = new venta();
        
        if(isset($_REQUEST['fecha'])){
            $venta = $this->model->ListarMes($_REQUEST['fecha']);
        }
        require_once 'view/informes/cierremespdf.php';
        
    }
        
    public function Factura(){
        
        require_once 'view/informes/facturapdf.php';
        
    }
    
    public function Obtener(){
        $venta = new venta();
        
        if(isset($_REQUEST['id'])){
            $venta = $this->model->Obtener($_REQUEST['id']);
        }
        
        require_once 'view/venta/venta-editar.php';
        
    }

    public function GuardarUno(){
         

        $venta = new venta();

        $costo = $_REQUEST['precio_costo']*$_REQUEST['cantidad'];
        $p_venta = $_REQUEST['precio_venta']*$_REQUEST['cantidad'];
        
        $venta->id = 0;
        $venta->id_venta = $_REQUEST['id_venta'];
        $venta->id_cliente = $_REQUEST['id_cliente'];
        $venta->id_vendedor = $_REQUEST['id_venta'];
        $venta->id_producto = $_REQUEST['id_producto'];
        $venta->id_res = 0;
        $venta->precio_costo = $_REQUEST['precio_costo'];
        $venta->precio_venta = $_REQUEST['precio_venta'];
        $venta->subtotal = $p_venta;
        $venta->descuento = 0;
        $venta->iva = 0;
        $venta->total = $p_venta;
        $venta->comprobante = $_REQUEST['comprobante'];
        $venta->nro_comprobante = $_REQUEST['nro_comprobante'];
        $venta->cantidad = $_REQUEST['cantidad'];
        $venta->margen_ganancia = round(((($p_venta - $costo)*100)/$costo),2);
        $venta->fecha_venta = $_REQUEST['fecha_venta'];
        $venta->metodo = $_REQUEST['metodo'];
        $venta->banco = $_REQUEST['banco'];
        $venta->contado = $_REQUEST['contado'];


        $this->producto->Restar($venta);
        

        $venta->id > 0 
            ? $this->model->Actualizar($venta)
            : $this->model->Registrar($venta);



        header('Location: index.php?c=venta_tmp&a=editar&id='.$venta->id_venta);
    }
    
    public function Guardar(){

        $ven = new venta();
        $ven = $this->model->Ultimo();
        $sumaTotal = 0;


        foreach($this->venta_tmp->Listar() as $v){

            $venta = new venta();

            $venta->id = 0;
            $venta->id_venta = $ven->id_venta+1;
            $venta->id_cliente = $_REQUEST['id_cliente'];
            $venta->id_vendedor = $v->id_vendedor;
            $venta->vendedor_salon = 0;
            $venta->id_producto = $v->id_producto;
            $venta->precio_costo = $v->precio_costo;
            $venta->precio_venta = $v->precio_venta;
            $venta->subtotal = $v->precio_venta*$v->cantidad;
            $venta->descuento = $v->descuento;
            $venta->iva = $_REQUEST['ivaval'];
            $venta->total = $venta->subtotal-($venta->subtotal*($venta->descuento/100));
            $venta->comprobante = $_REQUEST['comprobante'];
            $venta->nro_comprobante = $_REQUEST['nro_comprobante'];
            $venta->cantidad = $v->cantidad;
            $venta->margen_ganancia = ((($venta->precio_venta-($venta->precio_venta*($venta->descuento/100)))-$venta->precio_costo)/($venta->precio_costo))*100 ;
            $venta->fecha_venta = $_REQUEST["fecha_venta"];//date("Y-m-d H:i");
            $venta->metodo = $_REQUEST['pago'];
            $venta->contado = $_REQUEST['contado'];
            $venta->banco = $_REQUEST['banco'];
            
            $venta->fecha = $_REQUEST["fecha_venta"];//date("Y-m-d H:i");
            $venta->categoria = "Venta";
            $producto = $this->producto->Obtener($v->id_producto);
            $venta->concepto = $v->cantidad." Kg - ".$producto->producto; 
            $venta->monto = $venta->total;

            $venta->fecha_emision = $_REQUEST["fecha_venta"];//date("Y-m-d H:i");
            $venta->fecha_vencimiento = "2020-08-31";

            

            //Registrar venta
            $this->model->Registrar($venta);
            //Restar Stock
            $this->producto->Restar($venta);

            $sumaTotal+=$venta->total; 

        }
            
            $ingreso = new ingreso();
            
            
            $ingreso->id_cliente = $_REQUEST['id_cliente'];
            $cierre = $this->cierre->Consultar($_SESSION['user_id']);
            $ingreso->id_caja = ($cierre->id_caja)? $cierre->id_caja:$_SESSION['id_caja'];
            $ingreso->id_venta = $ven->id_venta+1;
            $ingreso->fecha = date("Y-m-d H:i");
            $ingreso->categoria = 'Venta';
            $ingreso->concepto = 'Venta al contado';
            $ingreso->comprobante = $_REQUEST['comprobante'].' N° '.$_REQUEST['nro_comprobante'];
            $ingreso->forma_pago = $_REQUEST['pago'].' '.$_REQUEST['banco'];
            $ingreso->monto = $sumaTotal;
            $ingreso->saldo = $sumaTotal - $_REQUEST['entrega'];
            $ingreso->sucursal = 0;
            
            if($_REQUEST['contado']=="Cuota"){
                $this->deuda->Registrar($ingreso);
                if($_REQUEST['entrega']>0){
                    $ingreso->categoria = 'Venta';
                    $ingreso->concepto = 'Venta cobro parcial';
                    $ingreso->monto = $_REQUEST['entrega'];
                    $this->ingreso->Registrar($ingreso);
                }
                session_start();
                $deuda = new deuda();
                $deuda->id_cliente = $_REQUEST['id_cliente'];
                $deuda->id_venta = $ven->id_venta+1;
                $deuda->fecha = date("Y-m-d",strtotime($_REQUEST['fecha_venta']));
                $deuda->concepto = "Venta a crédito";
                $deuda->monto = $sumaTotal;
                $deuda->saldo = $sumaTotal-$_REQUEST['entrega'];  
                $deuda->sucursal = $_SESSION['sucursal']; 
                $this->deuda->Registrar($deuda);
            }elseif($_REQUEST['contado']=="Credito"){
                session_start();
                $deuda = new deuda();
                $deuda->id_cliente = $_REQUEST['id_cliente'];
                $deuda->id_venta = $ven->id_venta+1;
                $deuda->fecha = date("Y-m-d",strtotime($_REQUEST['fecha_venta']));
                $deuda->concepto = "Venta a crédito";
                $deuda->monto = $sumaTotal;
                $deuda->saldo = $sumaTotal;  
                $deuda->sucursal = $_SESSION['sucursal']; 
                $this->deuda->Registrar($deuda);
            }else{
                $this->ingreso->Registrar($ingreso);
            }
            
            $this->venta_tmp->Vaciar();
            $puntos = intval($sumaTotal/50000);
            $this->cliente->SumarPuntos($puntos, $_REQUEST['id_cliente']);
            $this->cliente->SumarGastos($sumaTotal, $_REQUEST['id_cliente']);
            $id = $ven->id_venta+1;
            if($_REQUEST['comprobante'] == "Ticket" ){
                header('Location: index.php?c=venta&a=sesion');
            }else{
                //header('Location: index.php?c=venta&a=sesion');
                header("refresh:0;index.php?c=venta&a=factura&id=$id");
            }
            //header('Location: index.php?c=venta&a=sesion');
    }
    
    public function Eliminar(){
        
        foreach($this->model->Listar($_REQUEST['id']) as $v){
            $venta = new venta();
            $venta->id_producto = $v->codigo;
            $venta->cantidad = $v->cantidad;
            $this->producto->Sumar($venta);
        }
        $this->ingreso->EliminarVenta($_REQUEST['id']);
        $this->model->Eliminar($_REQUEST['id']);
        header('Location: index.php?c=venta');
    }

    public function Anular(){
        
        foreach($this->model->Listar($_REQUEST['id']) as $v){
            $venta = new venta();
            $venta->id_producto = $v->codigo;
            $venta->cantidad = $v->cantidad;
            $this->producto->Sumar($venta);
        }
        $this->ingreso->AnularVenta($_REQUEST['id']);
        $this->deuda->AnularVenta($_REQUEST['id']);
        $this->model->Anular($_REQUEST['id']);
        header('Location: index.php?c=venta');
    }
}